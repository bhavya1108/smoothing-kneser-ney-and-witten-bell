# How to run
```
    > python3 language_model.py n V ./data_file_path.txt
```
+ `V` can be
    + k : Kneyser-ney 
    + w : Witten-Bell 